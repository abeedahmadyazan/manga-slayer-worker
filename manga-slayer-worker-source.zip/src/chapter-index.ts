export type ChapterEntry = {
  slot: string;
  chapter_id: number;
  manga_id: number;
  chapter_number: number;
  chapter_label: string;
  chapter_name: string;
  chapter_folder_name: string;
  url: string;
  date_upload: number;
  chapter_watched_history_by_user: string;
  readable: boolean;
  credits: string;
  language?: string;
  alternatives_json?: string;
};

export function chapterSlot(label: unknown): string | null {
  if (typeof label !== "string" || !/^\d+(?:\.\d+)?$/.test(label)) return null;
  const number = Number(label);
  return Number.isFinite(number) && number >= 0 ? String(number) : null;
}

// Numbers and their discussion IDs survive missing upstream results and translation changes.
export function mergeChapterEntries(saved: ChapterEntry[], fresh: ChapterEntry[], refreshTranslations = false): ChapterEntry[] {
  const entries = new Map(saved.map(entry => [entry.slot, entry]));
  for (const entry of fresh) {
    const previous = entries.get(entry.slot);
    const rank = (language?: string) => !language || language === 'ar' ? 0 : language === 'en' ? 1 : 2;
    if (previous && (!entry.readable || previous.readable && !refreshTranslations &&
      (rank(previous.language) < rank(entry.language) || rank(previous.language) === rank(entry.language) && previous.date_upload > entry.date_upload))) continue;
    entries.set(entry.slot, previous ? {...entry, chapter_id: previous.chapter_id, url: previous.url} : entry);
  }
  return [...entries.values()].sort((a, b) => b.chapter_number - a.chapter_number || b.date_upload - a.date_upload);
}

export async function loadChapterIndex(db: D1Database, manga: number): Promise<ChapterEntry[]> {
  const result = await db.prepare("SELECT payload FROM source_chapter_index WHERE manga_id=?1 ORDER BY chapter_number DESC")
    .bind(manga).all<{payload: string}>();
  return result.results.map(row => JSON.parse(row.payload) as ChapterEntry);
}

export async function saveChapterIndex(db: D1Database, manga: number, entries: ChapterEntry[]): Promise<void> {
  for (let offset = 0; offset < entries.length; offset += 500) {
    const values = JSON.stringify(entries.slice(offset, offset + 500));
    await db.batch([
      db.prepare(`INSERT INTO source_chapter_index(manga_id,slot,chapter_id,chapter_number,payload)
        SELECT ?1,json_extract(value,'$.slot'),json_extract(value,'$.chapter_id'),json_extract(value,'$.chapter_number'),value FROM json_each(?2) WHERE 1
        ON CONFLICT(manga_id,slot) DO UPDATE SET payload=excluded.payload,chapter_number=excluded.chapter_number WHERE source_chapter_index.payload != excluded.payload`).bind(manga, values),
      db.prepare(`INSERT INTO documents(path,fields,updated_at)
        SELECT 'sourceChapters/'||json_extract(value,'$.chapter_id'),json_object(
          'localId',json_object('integerValue',CAST(json_extract(value,'$.chapter_id') AS TEXT)),
          'mangaId',json_object('integerValue',CAST(?1 AS TEXT)),
          'remoteId',json_object('stringValue',json_extract(value,'$.chapter_folder_name')),
          'credits',json_object('stringValue',json_extract(value,'$.credits')),
          'language',json_object('stringValue',COALESCE(json_extract(value,'$.language'),'ar')),
          'alternativesJson',json_object('stringValue',COALESCE(json_extract(value,'$.alternatives_json'),'[]')),
          'readable',json_object('booleanValue',json(CASE WHEN json_extract(value,'$.readable') THEN 'true' ELSE 'false' END))
        ),1 FROM json_each(?2) WHERE 1
        ON CONFLICT(path) DO UPDATE SET fields=excluded.fields,updated_at=documents.updated_at+1 WHERE documents.fields != excluded.fields`).bind(manga, values),
    ]);
  }
}
